export class NavBarList {
    name: string;
    path: string;
}
